import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './components/Home';
import DrawArt from './components/DrawArt';
import ColorArt from './components/ColorArt';
import AIEditing from './components/AIEditing';
import BackgroundRemover from './components/BackgroundRemover';
import ColorPhoto from './components/ColorPhoto';
import IndianAI from './components/IndianAI';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/draw-art" element={<DrawArt />} />
        <Route path="/color-art" element={<ColorArt />} />
        <Route path="/ai-editing" element={<AIEditing />} />
        <Route path="/background-remover" element={<BackgroundRemover />} />
        <Route path="/color-photo" element={<ColorPhoto />} />
        <Route path="/indian-ai" element={<IndianAI />} />
      </Routes>
    </BrowserRouter>
  );
}
