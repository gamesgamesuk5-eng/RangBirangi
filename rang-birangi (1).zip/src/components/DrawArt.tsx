import { useState, useRef } from 'react';
import { Stage, Layer, Line, Rect, Circle } from 'react-konva';
import { Link } from 'react-router-dom';

const COLORS = ['#000000', '#FF0000', '#0000FF', '#00FF00', '#FFFF00', '#FF00FF', '#00FFFF', '#FFFFFF'];
const BACKGROUND_IMAGES = Array.from({ length: 10 }, (_, i) => `https://picsum.photos/seed/art${i}/800/500`);

export default function DrawArt() {
  const [lines, setLines] = useState<any[]>([]);
  const [shapes, setShapes] = useState<any[]>([]);
  const [color, setColor] = useState('#000000');
  const [tool, setTool] = useState<'pen' | 'rect' | 'circle'>('pen');
  const [bgImage, setBgImage] = useState<string | null>(null);
  const stageRef = useRef<any>(null);
  const isDrawing = useRef(false);

  const handleMouseDown = (e: any) => {
    isDrawing.current = true;
    const pos = e.target.getStage().getPointerPosition();
    if (tool === 'pen') {
      setLines([...lines, { points: [pos.x, pos.y], color, tool: color === '#FFFFFF' ? 'eraser' : 'pen' }]);
    } else {
      setShapes([...shapes, { x: pos.x, y: pos.y, width: 0, height: 0, color, tool }]);
    }
  };

  const handleMouseMove = (e: any) => {
    if (!isDrawing.current) return;
    const stage = e.target.getStage();
    const point = stage.getPointerPosition();
    if (tool === 'pen') {
      let lastLine = lines[lines.length - 1];
      lastLine.points = lastLine.points.concat([point.x, point.y]);
      lines.splice(lines.length - 1, 1, lastLine);
      setLines([...lines]);
    } else {
      let lastShape = shapes[shapes.length - 1];
      lastShape.width = point.x - lastShape.x;
      lastShape.height = point.y - lastShape.y;
      shapes.splice(shapes.length - 1, 1, lastShape);
      setShapes([...shapes]);
    }
  };

  const handleMouseUp = () => {
    isDrawing.current = false;
  };

  const clearCanvas = () => {
    setLines([]);
    setShapes([]);
    setBgImage(null);
  };

  const downloadCanvas = () => {
    const uri = stageRef.current.toDataURL();
    const link = document.createElement('a');
    link.download = 'draw-art.png';
    link.href = uri;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-8">
      <Link to="/" className="text-stone-600 hover:text-stone-900 mb-4 inline-block">&larr; Back</Link>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-xl">
          IN
        </div>
        <div>
          <h2 className="text-2xl font-bold">Draw Art (by Indian AI)</h2>
          <p className="text-sm text-stone-500">नमस्ते! मैं Indian AI हूँ। यहाँ आप अपनी कलाकारी दिखा सकते हैं।</p>
        </div>
      </div>
      
      <div className="mb-4">
        <p className="mb-2 font-medium">Select Background:</p>
        <div className="grid grid-cols-5 gap-2">
          {BACKGROUND_IMAGES.map((img, i) => (
            <img key={i} src={img} alt={`Art ${i}`} onClick={() => setBgImage(img)} className="cursor-pointer border border-stone-300 rounded-lg hover:border-orange-500" />
          ))}
        </div>
      </div>

      <div className="flex gap-2 mb-4 items-center flex-wrap">
        {COLORS.map((c) => (
          <button
            key={c}
            className={`w-8 h-8 rounded-full border-2 ${color === c ? 'border-stone-900 scale-110' : 'border-transparent'}`}
            style={{ backgroundColor: c }}
            onClick={() => setColor(c)}
          />
        ))}
        <div className="w-px h-8 bg-stone-300 mx-2"></div>
        <button onClick={() => setTool('pen')} className={`px-4 py-2 rounded-xl ${tool === 'pen' ? 'bg-orange-500 text-white' : 'bg-stone-200'}`}>Pen</button>
        <button onClick={() => setTool('rect')} className={`px-4 py-2 rounded-xl ${tool === 'rect' ? 'bg-orange-500 text-white' : 'bg-stone-200'}`}>Rect</button>
        <button onClick={() => setTool('circle')} className={`px-4 py-2 rounded-xl ${tool === 'circle' ? 'bg-orange-500 text-white' : 'bg-stone-200'}`}>Circle</button>
        <button onClick={clearCanvas} className="ml-auto px-4 py-2 bg-stone-200 text-stone-900 rounded-xl hover:bg-stone-300">Clear</button>
      </div>
      <div className="border-2 border-stone-300 rounded-xl overflow-hidden bg-white relative shadow-sm">
        {bgImage && <img src={bgImage} alt="Background" className="absolute top-0 left-0 w-full h-full object-cover" />}
        <Stage
          ref={stageRef}
          width={window.innerWidth > 800 ? 800 : window.innerWidth - 64}
          height={500}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onTouchStart={handleMouseDown}
          onTouchMove={handleMouseMove}
          onTouchEnd={handleMouseUp}
        >
          <Layer>
            {lines.map((line, i) => (
              <Line
                key={i}
                points={line.points}
                stroke={line.color}
                strokeWidth={line.tool === 'eraser' ? 20 : 5}
                tension={0.5}
                lineCap="round"
                lineJoin="round"
                globalCompositeOperation={line.tool === 'eraser' ? 'destination-out' : 'source-over'}
              />
            ))}
            {shapes.map((shape, i) => {
              if (shape.tool === 'rect') {
                return <Rect key={i} x={shape.x} y={shape.y} width={shape.width} height={shape.height} stroke={shape.color} strokeWidth={2} />;
              }
              if (shape.tool === 'circle') {
                return <Circle key={i} x={shape.x} y={shape.y} radius={Math.abs(shape.width / 2)} stroke={shape.color} strokeWidth={2} />;
              }
              return null;
            })}
          </Layer>
        </Stage>
      </div>
      <button onClick={downloadCanvas} className="mt-6 px-8 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-medium shadow-sm transition-colors">Download Art</button>
    </div>
  );
}
