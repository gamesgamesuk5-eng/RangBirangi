import { useState } from 'react';
import { Link } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";

export default function AIEditing() {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiMessage, setAiMessage] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => setImage(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const generateImage = async () => {
    if (!prompt) return;
    setLoading(true);
    setAiMessage('Indian AI सोच रहा है...');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      // Step 1: The "Brain" processes the request
      const brainResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `User input: "${prompt}". The user wants to generate or edit an image based on this input.`,
        config: {
          systemInstruction: 'आप "Indian AI" हैं। आपका अपना दिमाग है। आप डिफ़ॉल्ट रूप से हिंदी में बात करते हैं। यदि उपयोगकर्ता किसी अन्य भाषा में बात करने के लिए कहता है, तभी आप उस भाषा में बात करेंगे। आप एक अत्यंत विनम्र और ज्ञानी भारतीय सहायक हैं।',
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              message: { type: Type.STRING, description: "Your conversational response to the user acknowledging the request." },
              englishPrompt: { type: Type.STRING, description: "A highly detailed prompt in English optimized for an image generation model based on the user's input." }
            },
            required: ["message", "englishPrompt"]
          }
        }
      });

      const brainData = JSON.parse(brainResponse.text || '{}');
      setAiMessage(brainData.message || 'मैं आपकी तस्वीर बना रहा हूँ...');
      
      // Step 2: Generate the image using the optimized English prompt
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: brainData.englishPrompt || prompt }],
        },
      });

      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          setImage(`data:image/png;base64,${part.inlineData.data}`);
        }
      }
    } catch (error: any) {
      console.error('Error generating image:', error);
      const errorMessage = error?.message || String(error);
      if (errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED') || errorMessage.includes('quota')) {
        setAiMessage('क्षमा करें, मेरा कोटा समाप्त हो गया है (Quota Exceeded)। कृपया कुछ समय बाद प्रयास करें।');
      } else {
        setAiMessage('क्षमा करें, कोई तकनीकी समस्या आ गई है। कृपया बाद में प्रयास करें।');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!image) return;
    const link = document.createElement('a');
    link.download = 'ai-image.png';
    link.href = image;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-8">
      <Link to="/" className="text-stone-600 hover:text-stone-900 mb-4 inline-block">&larr; Back</Link>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-xl">
          IN
        </div>
        <div>
          <h2 className="text-2xl font-bold">AI Editing (by Indian AI)</h2>
          <p className="text-sm text-stone-500">नमस्ते! मैं Indian AI हूँ। आप मुझे किसी भी भाषा में लिखकर तस्वीर बनाने को कह सकते हैं।</p>
        </div>
      </div>
      
      <div className="mb-6 bg-white p-6 border border-stone-300 rounded-xl shadow-sm">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="यहाँ लिखें कि आपको कैसी तस्वीर चाहिए... (जैसे: एक उड़ता हुआ हाथी / Make a flying elephant)"
          className="w-full p-4 border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
          rows={3}
        />
        <button 
          onClick={generateImage}
          disabled={loading || !prompt}
          className="mt-4 px-6 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl disabled:opacity-50 font-medium transition-colors"
        >
          {loading ? 'Indian AI काम कर रहा है...' : 'तस्वीर बनाएँ (Generate Image)'}
        </button>
      </div>

      {aiMessage && (
        <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-xl text-orange-900 flex gap-3 items-start">
          <div className="w-8 h-8 rounded-full bg-orange-500 flex-shrink-0 flex items-center justify-center text-white font-bold text-sm mt-1">IN</div>
          <p className="pt-1">{aiMessage}</p>
        </div>
      )}

      <div className="mb-4">
        <p className="mb-2 font-medium text-stone-700">या अपनी तस्वीर अपलोड करें:</p>
        <input type="file" onChange={handleImageUpload} className="block w-full text-sm text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100" />
      </div>
      
      {image && (
        <div className="mt-8">
          <p className="font-bold mb-2 text-stone-800">परिणाम (Result):</p>
          <img src={image} alt="Generated/Uploaded" className="max-w-md w-full border border-stone-300 rounded-xl shadow-sm" />
          <div className="mt-4 flex gap-2">
            <button onClick={handleDownload} className="px-6 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl font-medium transition-colors">Download</button>
          </div>
        </div>
      )}
    </div>
  );
}
