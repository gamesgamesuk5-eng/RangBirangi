import { useState } from 'react';
import { Link } from 'react-router-dom';
import { removeBackground as imglyRemoveBackground } from '@imgly/background-removal';
import { GoogleGenAI, Type } from "@google/genai";

export default function BackgroundRemover() {
  const [image, setImage] = useState<string | null>(null);
  const [bg, setBg] = useState<string>('transparent');
  const [bgPrompt, setBgPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [aiMessage, setAiMessage] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target?.result as string);
        setResult(null);
        setAiMessage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const downloadImage = () => {
    if (!result) return;
    
    if (bg !== 'transparent' && !bgPrompt.trim()) {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        if (ctx) {
          ctx.fillStyle = bg;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);
          const link = document.createElement('a');
          link.download = 'indian-ai-bg-removed.png';
          link.href = canvas.toDataURL('image/png');
          link.click();
        }
      };
      img.src = result;
    } else {
      const link = document.createElement('a');
      link.href = result;
      link.download = 'indian-ai-bg-removed.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const removeBackground = async () => {
    if (!image) return;
    setLoading(true);
    
    try {
      if (bgPrompt.trim()) {
        // AI Background Replacement via Gemini
        setAiMessage('Indian AI सोच रहा है...');
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
        const base64Image = image.split(',')[1];
        
        // Step 1: The "Brain" processes the request
        const brainResponse = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `User input for background replacement: "${bgPrompt}".`,
          config: {
            systemInstruction: 'आप "Indian AI" हैं। आपका अपना दिमाग है। आप डिफ़ॉल्ट रूप से हिंदी में बात करते हैं। यदि उपयोगकर्ता किसी अन्य भाषा में बात करने के लिए कहता है, तभी आप उस भाषा में बात करेंगे। आप एक अत्यंत विनम्र और ज्ञानी भारतीय सहायक हैं।',
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                message: { type: Type.STRING, description: "Your conversational response to the user acknowledging the request." },
                englishPrompt: { type: Type.STRING, description: "A highly detailed prompt in English optimized for an image editing model to replace the background based on the user's input." }
              },
              required: ["message", "englishPrompt"]
            }
          }
        });

        const brainData = JSON.parse(brainResponse.text || '{}');
        setAiMessage(brainData.message || 'मैं बैकग्राउंड बदल रहा हूँ...');
        const finalPrompt = `Remove the background from this image and replace it with: ${brainData.englishPrompt || bgPrompt}`;
        
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              {
                inlineData: {
                  data: base64Image,
                  mimeType: 'image/png',
                },
              },
              { text: finalPrompt },
            ],
          },
        });

        const candidate = response.candidates?.[0];
        if (candidate?.content?.parts) {
          for (const part of candidate.content.parts) {
            if (part.inlineData) {
              setResult(`data:image/png;base64,${part.inlineData.data}`);
              setAiMessage('नया बैकग्राउंड सफलतापूर्वक लगा दिया गया है!');
            }
          }
        } else {
          throw new Error('No image returned from AI');
        }
      } else {
        // Pure Background Removal via @imgly (Free & Local)
        setAiMessage('Indian AI मॉडल लोड हो रहा है... (पहली बार में थोड़ा समय लग सकता है, लेकिन यह बिल्कुल फ्री है!)');
        const blob = await imglyRemoveBackground(image, {
          progress: (key, current, total) => {
            const percent = Math.round((current / total) * 100);
            setAiMessage(`प्रोसेसिंग: ${percent}%`);
          }
        });
        
        const url = URL.createObjectURL(blob);
        setResult(url);
        setAiMessage('बैकग्राउंड सफलतापूर्वक हटा दिया गया! (यह पूरी तरह से आपके डिवाइस पर फ्री में हुआ है)');
      }
    } catch (error: any) {
      console.error('Error removing background:', error);
      const errorMessage = error?.message || String(error);
      if (errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED') || errorMessage.includes('quota')) {
        setAiMessage('क्षमा करें, मेरा कोटा समाप्त हो गया है (Quota Exceeded)। कृपया कुछ समय बाद प्रयास करें।');
      } else {
        setAiMessage('क्षमा करें, कोई तकनीकी समस्या आ गई है। कृपया बाद में प्रयास करें।');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8">
      <Link to="/" className="text-stone-600 hover:text-stone-900 mb-4 inline-block">&larr; Back</Link>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-xl">
          IN
        </div>
        <div>
          <h2 className="text-2xl font-bold">Background Remover (by Indian AI)</h2>
          <p className="text-sm text-stone-500">नमस्ते! मैं Indian AI हूँ। मैं आपकी फोटो का बैकग्राउंड हटा सकता हूँ या नया बैकग्राउंड लगा सकता हूँ।</p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-white p-6 border border-stone-300 rounded-xl shadow-sm">
        <div>
          <p className="mb-2 font-medium text-stone-700">Upload Image (फोटो अपलोड करें):</p>
          <input type="file" accept="image/*" onChange={handleImageUpload} className="mb-4 block w-full text-sm text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100" />
          {image && <img src={image} alt="Uploaded" className="max-w-xs border border-stone-300 rounded-xl shadow-sm" />}
        </div>
        <div className="flex flex-col gap-4">
          <div>
            <p className="mb-2 font-medium text-stone-700">Background Color (नया रंग चुनें):</p>
            <div className="flex items-center gap-4">
              <input 
                type="color" 
                value={bg === 'transparent' ? '#ffffff' : bg}
                onChange={(e) => { setBg(e.target.value); setBgPrompt(''); }} 
                disabled={bgPrompt.trim().length > 0}
                className="w-16 h-12 rounded cursor-pointer border-0 p-0 disabled:opacity-50" 
              />
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={bg === 'transparent'} 
                  onChange={(e) => { setBg(e.target.checked ? 'transparent' : '#ffffff'); setBgPrompt(''); }}
                  disabled={bgPrompt.trim().length > 0}
                  className="w-5 h-5 text-orange-500 rounded focus:ring-orange-500 disabled:opacity-50"
                />
                <span className="text-stone-700 font-medium">Transparent (पारदर्शी)</span>
              </label>
            </div>
          </div>
          <div>
            <p className="mb-2 font-medium text-stone-700">AI Background (नया बैकग्राउंड - वैकल्पिक):</p>
            <textarea 
              value={bgPrompt} 
              onChange={(e) => { setBgPrompt(e.target.value); if(e.target.value) setBg('transparent'); }} 
              className="w-full p-4 border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500" 
              placeholder="e.g., make it a beach scene (जैसे: पीछे समुद्र तट लगा दें)" 
              rows={3}
            />
          </div>
          <div className="p-4 bg-orange-50 rounded-xl border border-orange-100">
            <p className="text-sm text-orange-800">
              <strong>नोट:</strong> अगर आप सिर्फ बैकग्राउंड हटाते हैं या रंग बदलते हैं, तो यह 100% फ्री है। अगर आप AI से नया बैकग्राउंड बनवाते हैं (टेक्स्ट लिखकर), तो उसमें AI का इस्तेमाल होगा।
            </p>
          </div>
        </div>
      </div>
      
      {image && (
        <div className="mt-6">
          <button 
            onClick={removeBackground}
            disabled={loading}
            className="px-6 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl disabled:opacity-50 font-medium transition-colors"
          >
            {loading ? 'Indian AI काम कर रहा है...' : (bgPrompt.trim() ? 'नया बैकग्राउंड लगाएँ (Replace Background)' : 'बैकग्राउंड हटाएँ (Remove Background)')}
          </button>
          
          {aiMessage && (
            <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-xl text-orange-900 flex gap-3 items-start max-w-2xl">
              <div className="w-8 h-8 rounded-full bg-orange-500 flex-shrink-0 flex items-center justify-center text-white font-bold text-sm mt-1">IN</div>
              <p className="pt-1">{aiMessage}</p>
            </div>
          )}

          {result && (
            <div className="mt-6 p-6 rounded-xl border border-stone-200 shadow-sm inline-block" style={{ backgroundColor: bg === 'transparent' ? 'transparent' : bg, backgroundImage: bg === 'transparent' && !bgPrompt.trim() ? 'url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAMUlEQVQ4T2NkYGAQYcAP3uCTZhw1gGGYhAGBZIA/nYDCgBDAm9BGDWAAJyEgkAARBgAqQgITkQ8B/QAAAABJRU5ErkJggg==")' : 'none' }}>
              <p className="font-bold mb-4 text-stone-800 bg-white/80 inline-block px-2 py-1 rounded">परिणाम (Result):</p>
              <br />
              <img src={result} alt="Result" className="max-w-xs border border-stone-300 rounded-lg shadow-sm" />
              <button onClick={downloadImage} className="mt-4 px-6 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl block font-medium transition-colors">Download</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
