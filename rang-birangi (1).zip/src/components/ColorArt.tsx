import { useState } from 'react';
import { Link } from 'react-router-dom';

const COLORS = ['#f87171', '#fb923c', '#facc15', '#4ade80', '#60a5fa', '#a78bfa', '#f472b6', '#ffffff', '#000000'];

const INITIAL_PAGES = [
  { id: 1, name: 'Indian Flag' },
  { id: 2, name: 'Child' },
  { id: 3, name: 'Owl' },
  { id: 4, name: 'Butterfly' },
  { id: 5, name: 'Dog' },
  { id: 6, name: 'Horse' },
  { id: 7, name: 'Shiva Ji' },
];

export default function ColorArt() {
  const [selectedPage, setSelectedPage] = useState<number | null>(null);
  const [selectedColor, setSelectedColor] = useState('#f87171');
  const [pageColors, setPageColors] = useState<Record<number, Record<string, string>>>({});
  const [pages, setPages] = useState(INITIAL_PAGES);

  const loadMore = () => {
    const newPages = Array.from({ length: 10 }, (_, i) => ({
      id: pages.length + i + 1,
      name: `Coloring Page ${pages.length + i + 1}`
    }));
    setPages([...pages, ...newPages]);
  };

  const handleSectionClick = (pageId: number, section: string) => {
    setPageColors(prev => ({
      ...prev,
      [pageId]: { ...(prev[pageId] || {}), [section]: selectedColor }
    }));
  };

  const getSectionColor = (pageId: number, section: string) => pageColors[pageId]?.[section] || '#ffffff';

  const renderPage = () => {
    switch (selectedPage) {
      case 1: // Indian Flag
        return (
          <svg viewBox="0 0 300 200" className="w-full max-w-md border border-stone-900">
            <rect x="0" y="0" width="300" height="66" fill={getSectionColor(1, 'top')} onClick={() => handleSectionClick(1, 'top')} className="cursor-pointer" stroke="black" />
            <rect x="0" y="66" width="300" height="68" fill={getSectionColor(1, 'middle')} onClick={() => handleSectionClick(1, 'middle')} className="cursor-pointer" stroke="black" />
            <rect x="0" y="134" width="300" height="66" fill={getSectionColor(1, 'bottom')} onClick={() => handleSectionClick(1, 'bottom')} className="cursor-pointer" stroke="black" />
          </svg>
        );
      default:
        return <div className="p-4 text-stone-600">Coloring page for {pages.find(p => p.id === selectedPage)?.name} is under development.</div>;
    }
  };

  const handleDownload = () => {
    alert('Download initiated!');
  };

  return (
    <div className="p-8">
      <Link to="/" className="text-stone-600 hover:text-stone-900 mb-4 inline-block">&larr; Back</Link>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-xl">
          IN
        </div>
        <div>
          <h2 className="text-2xl font-bold">Color Art (by Indian AI)</h2>
          <p className="text-sm text-stone-500">नमस्ते! मैं Indian AI हूँ। चलिए इन चित्रों में रंग भरते हैं।</p>
        </div>
      </div>
      
      {selectedPage === null ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {pages.map((page) => (
              <button
                key={page.id}
                onClick={() => setSelectedPage(page.id)}
                className="aspect-square bg-white border border-stone-200 rounded-lg flex flex-col items-center justify-center text-stone-600 hover:border-orange-500 hover:text-orange-600 transition-colors shadow-sm"
              >
                {page.name}
              </button>
            ))}
          </div>
          <button onClick={loadMore} className="mt-6 px-6 py-2 bg-stone-200 text-stone-900 rounded-xl hover:bg-stone-300">Load More</button>
        </>
      ) : (
        <div className="bg-white p-6 border border-stone-300 rounded-xl shadow-sm">
          <button onClick={() => setSelectedPage(null)} className="mb-4 text-stone-600 hover:text-stone-900">&larr; Back to Gallery</button>
          
          <div className="flex gap-4 mb-6 flex-wrap">
            {COLORS.map(c => (
              <button key={c} className={`w-10 h-10 rounded-full border-2 ${selectedColor === c ? 'border-stone-900 scale-110 shadow-md' : 'border-transparent shadow-sm'}`} style={{ backgroundColor: c }} onClick={() => setSelectedColor(c)} />
            ))}
          </div>

          <div className="flex flex-col items-center">
            <h3 className="text-xl font-bold mb-4">{pages.find(p => p.id === selectedPage)?.name}</h3>
            {renderPage()}
            <p className="mt-4 text-stone-600">Select a color and click on a section to color it!</p>
          </div>
        </div>
      )}
      
      {selectedPage !== null && (
        <button onClick={handleDownload} className="mt-6 px-8 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-medium shadow-sm transition-colors">Download</button>
      )}
    </div>
  );
}
