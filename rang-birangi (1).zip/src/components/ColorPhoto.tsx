import { useState } from 'react';
import { Link } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";

export default function ColorPhoto() {
  const [image1, setImage1] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [aiMessage, setAiMessage] = useState<string | null>(null);

  const downloadImage = (dataUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<string | null>>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => setter(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const colorizePhoto = async () => {
    if (!image1) return;
    setLoading(true);
    setAiMessage('Indian AI सोच रहा है...');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const base64Image = image1.split(',')[1];
      
      let finalPrompt = 'Colorize this black and white photo realistically.';
      
      if (prompt.trim()) {
        // Step 1: The "Brain" processes the request
        const brainResponse = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `User input for photo colorization: "${prompt}".`,
          config: {
            systemInstruction: 'आप "Indian AI" हैं। आपका अपना दिमाग है। आप डिफ़ॉल्ट रूप से हिंदी में बात करते हैं। यदि उपयोगकर्ता किसी अन्य भाषा में बात करने के लिए कहता है, तभी आप उस भाषा में बात करेंगे। आप एक अत्यंत विनम्र और ज्ञानी भारतीय सहायक हैं।',
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                message: { type: Type.STRING, description: "Your conversational response to the user acknowledging the request." },
                englishPrompt: { type: Type.STRING, description: "A highly detailed prompt in English optimized for an image editing model to colorize the photo based on the user's input." }
              },
              required: ["message", "englishPrompt"]
            }
          }
        });

        const brainData = JSON.parse(brainResponse.text || '{}');
        setAiMessage(brainData.message || 'मैं आपकी फोटो में रंग भर रहा हूँ...');
        finalPrompt = `Colorize this photo with this instruction: ${brainData.englishPrompt || prompt}`;
      } else {
        setAiMessage('मैं आपकी फोटो में रंग भर रहा हूँ...');
      }
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Image,
                mimeType: 'image/png',
              },
            },
            { text: finalPrompt },
          ],
        },
      });

      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          setResult(`data:image/png;base64,${part.inlineData.data}`);
        }
      }
    } catch (error: any) {
      console.error('Error colorizing photo:', error);
      const errorMessage = error?.message || String(error);
      if (errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED') || errorMessage.includes('quota')) {
        setAiMessage('क्षमा करें, मेरा कोटा समाप्त हो गया है (Quota Exceeded)। कृपया कुछ समय बाद प्रयास करें।');
      } else {
        setAiMessage('क्षमा करें, कोई तकनीकी समस्या आ गई है। कृपया बाद में प्रयास करें।');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8">
      <Link to="/" className="text-stone-600 hover:text-stone-900 mb-4 inline-block">&larr; Back</Link>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-xl">
          IN
        </div>
        <div>
          <h2 className="text-2xl font-bold">Color Photo (by Indian AI)</h2>
          <p className="text-sm text-stone-500">नमस्ते! मैं Indian AI हूँ। मैं आपकी ब्लैक एंड वाइट फोटो में रंग भर सकता हूँ।</p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-white p-6 border border-stone-300 rounded-xl shadow-sm">
        <div>
          <p className="mb-2 font-medium text-stone-700">Target Photo (फोटो अपलोड करें):</p>
          <input type="file" onChange={(e) => handleUpload(e, setImage1)} className="mb-4 block w-full text-sm text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100" />
          {image1 && <img src={image1} alt="Target" className="mt-2 max-w-xs border border-stone-300 rounded-xl shadow-sm" />}
        </div>
        <div>
          <p className="mb-2 font-medium text-stone-700">Instruction (कोई निर्देश देना चाहें तो लिखें):</p>
          <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} className="w-full p-4 border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500" placeholder="e.g., make it vintage (इसे पुराना लुक दें)" rows={4} />
        </div>
      </div>
      <div className="mt-6">
        <button 
          onClick={colorizePhoto}
          disabled={loading || !image1}
          className="px-6 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl disabled:opacity-50 font-medium transition-colors"
        >
          {loading ? 'Indian AI रंग भर रहा है...' : 'रंग भरें (Colorize)'}
        </button>
        
        {aiMessage && (
          <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-xl text-orange-900 flex gap-3 items-start max-w-2xl">
            <div className="w-8 h-8 rounded-full bg-orange-500 flex-shrink-0 flex items-center justify-center text-white font-bold text-sm mt-1">IN</div>
            <p className="pt-1">{aiMessage}</p>
          </div>
        )}

        {result && (
          <div className="mt-8 p-6 bg-white border border-stone-200 rounded-xl shadow-sm inline-block">
            <p className="font-bold mb-4 text-stone-800">परिणाम (Result):</p>
            <img src={result} alt="Result" className="max-w-xs border border-stone-300 rounded-lg shadow-sm" />
            <button onClick={() => downloadImage(result, 'result.png')} className="mt-4 px-6 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl font-medium transition-colors block">Download</button>
          </div>
        )}
      </div>
    </div>
  );
}
