import { Link } from 'react-router-dom';
import { Palette, Pencil, Sparkles, Image as ImageIcon, Scissors, Bot } from 'lucide-react';

export default function Home() {
  const features = [
    { name: 'Draw Art', path: '/draw-art', icon: Pencil, description: 'Sketch and generate' },
    { name: 'Color Art', path: '/color-art', icon: Palette, description: 'Colorize your sketches' },
    { name: 'AI Editing', path: '/ai-editing', icon: Sparkles, description: 'Edit with text prompts' },
    { name: 'Background Remover', path: '/background-remover', icon: Scissors, description: 'Remove or replace backgrounds' },
    { name: 'Color Photo', path: '/color-photo', icon: ImageIcon, description: 'Colorize black & white photos' },
  ];

  return (
    <div className="min-h-screen bg-stone-50 p-8 font-sans">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-stone-900 mb-4 tracking-tight">Rang Birangi</h1>
          <p className="text-xl text-stone-500">Powered by your smart Indian AI Assistant</p>
        </div>

        {/* Highlighted Indian AI Card */}
        <Link
          to="/indian-ai"
          className="block mb-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1"
        >
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center text-orange-600 font-bold text-3xl shadow-inner">
              IN
            </div>
            <div className="text-white">
              <h2 className="text-3xl font-bold mb-2 flex items-center gap-3">
                <Bot className="w-8 h-8" />
                Chat with Indian AI
              </h2>
              <p className="text-orange-100 text-lg">
                आपका अपना स्मार्ट सहायक। मुझसे बातें करें या कोई भी तस्वीर बनवाएं! (Your smart assistant. Chat with me or ask me to generate any image!)
              </p>
            </div>
          </div>
        </Link>

        <h3 className="text-2xl font-bold text-stone-800 mb-6 px-2">Creative Tools</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <Link
              key={feature.name}
              to={feature.path}
              className="flex flex-col p-6 bg-white rounded-2xl shadow-sm hover:shadow-md transition-all border border-stone-200 hover:border-orange-300 group"
            >
              <div className="flex items-center gap-4 mb-3">
                <div className="p-3 bg-stone-100 rounded-xl group-hover:bg-orange-100 transition-colors">
                  <feature.icon className="w-6 h-6 text-stone-600 group-hover:text-orange-600" />
                </div>
                <span className="text-lg font-bold text-stone-800 group-hover:text-orange-600 transition-colors">{feature.name}</span>
              </div>
              <p className="text-stone-500 text-sm">{feature.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
