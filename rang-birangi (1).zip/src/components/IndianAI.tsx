import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";

export default function IndianAI() {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string, image?: string }[]>([
    { role: 'ai', text: 'नमस्ते! मैं Indian AI हूँ। मैं आपके लिए चित्र, 3D मॉडल (तस्वीरें) और वीडियो के फ्रेम बना सकता हूँ, या हम बस बातें कर सकते हैं। आप मुझसे क्या करवाना चाहते हैं?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMessage = input;
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setInput('');
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      // Step 1: The "Brain" processes the request to determine intent and generate response/prompt
      const brainResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `User input: "${userMessage}". Determine if the user is asking to generate, draw, or create an image/photo/picture/3D model/video frame. If yes, set isImageRequest to true and provide a highly detailed englishImagePrompt. If no, just provide a conversational chatResponse.`,
        config: {
          systemInstruction: 'आप "Indian AI" हैं। आपका अपना दिमाग है। आप डिफ़ॉल्ट रूप से हिंदी में बात करते हैं। यदि उपयोगकर्ता किसी अन्य भाषा में बात करने के लिए कहता है, तभी आप उस भाषा में बात करेंगे। आप एक अत्यंत विनम्र, सहायक और ज्ञानी भारतीय सहायक हैं।',
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              chatResponse: { type: Type.STRING, description: "Your conversational response to the user in Hindi (or requested language)." },
              isImageRequest: { type: Type.BOOLEAN, description: "True if the user is asking to generate or create an image/photo/3D model/video frame." },
              englishImagePrompt: { type: Type.STRING, description: "If isImageRequest is true, provide a highly detailed prompt in English optimized for an image generation model based on the user's request." }
            },
            required: ["chatResponse", "isImageRequest"]
          }
        }
      });

      const brainData = JSON.parse(brainResponse.text || '{}');
      
      // Add the conversational response first
      setMessages(prev => [...prev, { role: 'ai', text: brainData.chatResponse || 'मैं समझ रहा हूँ...' }]);

      // Step 2: If it's an image request, generate the image
      if (brainData.isImageRequest && brainData.englishImagePrompt) {
        setMessages(prev => [...prev, { role: 'ai', text: 'तस्वीर बनाई जा रही है, कृपया प्रतीक्षा करें... (Generating image...)' }]);
        
        const imageResponse = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [{ text: brainData.englishImagePrompt }],
          },
        });

        let base64Image = '';
        for (const part of imageResponse.candidates?.[0]?.content?.parts || []) {
          if (part.inlineData) {
            base64Image = `data:image/png;base64,${part.inlineData.data}`;
          }
        }

        if (base64Image) {
          setMessages(prev => {
            const newMessages = [...prev];
            // Replace the "Generating image..." message with the actual image
            newMessages[newMessages.length - 1] = { role: 'ai', text: 'यह लीजिए, आपकी तस्वीर तैयार है:', image: base64Image };
            return newMessages;
          });
        } else {
          setMessages(prev => {
            const newMessages = [...prev];
            newMessages[newMessages.length - 1] = { role: 'ai', text: 'क्षमा करें, मैं यह तस्वीर नहीं बना सका।' };
            return newMessages;
          });
        }
      }
    } catch (error: any) {
      console.error('Error:', error);
      const errorMessage = error?.message || String(error);
      if (errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED') || errorMessage.includes('quota')) {
        setMessages(prev => [...prev, { role: 'ai', text: 'क्षमा करें, मेरा कोटा समाप्त हो गया है (Quota Exceeded)। कृपया कुछ समय बाद प्रयास करें।' }]);
      } else {
        setMessages(prev => [...prev, { role: 'ai', text: 'क्षमा करें, कुछ तकनीकी समस्या आ गई है। कृपया बाद में प्रयास करें।' }]);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-3xl mx-auto flex flex-col h-screen">
      <div className="flex-shrink-0">
        <Link to="/" className="text-stone-600 hover:text-stone-900 mb-4 inline-block">&larr; Back</Link>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-2xl shadow-md">
            IN
          </div>
          <div>
            <h2 className="text-3xl font-bold text-stone-800">Indian AI</h2>
            <p className="text-sm text-stone-500">आपका अपना स्मार्ट भारतीय सहायक</p>
          </div>
        </div>
      </div>
      
      <div className="flex-grow overflow-y-auto border border-stone-300 rounded-2xl p-6 mb-6 bg-stone-50 flex flex-col gap-6 shadow-inner">
        {messages.map((m, i) => (
          <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`flex items-end gap-2 max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              {m.role === 'ai' && (
                <div className="w-8 h-8 rounded-full bg-orange-500 flex-shrink-0 flex items-center justify-center text-white font-bold text-xs shadow-sm mb-1">
                  IN
                </div>
              )}
              <div className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                <span className={`inline-block p-4 rounded-2xl ${m.role === 'user' ? 'bg-orange-500 text-white rounded-br-sm shadow-md' : 'bg-white border border-stone-200 text-stone-800 rounded-bl-sm shadow-sm'}`}>
                  {m.text}
                </span>
                {m.image && (
                  <img src={m.image} alt="Generated" className="mt-3 rounded-xl border border-stone-200 shadow-md w-full object-cover" />
                )}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-end gap-2 max-w-[85%]">
            <div className="w-8 h-8 rounded-full bg-orange-500 flex-shrink-0 flex items-center justify-center text-white font-bold text-xs shadow-sm mb-1">
              IN
            </div>
            <div className="inline-block p-4 rounded-2xl bg-white border border-stone-200 text-stone-500 rounded-bl-sm shadow-sm italic">
              Indian AI सोच रहा है...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      <div className="flex-shrink-0 flex gap-3 bg-white p-2 rounded-2xl border border-stone-300 shadow-sm">
        <input 
          value={input} 
          onChange={(e) => setInput(e.target.value)} 
          className="flex-grow p-4 bg-transparent focus:outline-none text-stone-800" 
          placeholder="मुझसे कुछ भी पूछें या तस्वीर बनाने को कहें..." 
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
        />
        <button 
          onClick={handleSend} 
          disabled={loading || !input.trim()} 
          className="px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white rounded-xl disabled:opacity-50 font-bold transition-colors shadow-sm"
        >
          भेजें
        </button>
      </div>
    </div>
  );
}
